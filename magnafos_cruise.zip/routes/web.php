<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;


Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::prefix('admin')->middleware(['auth'])->group(function() {
    Route::get('/dashboard', [App\Http\Controllers\Admin\DashController::class, 'index'])->name('admin.dashboard');

    //Customers Routes
    Route::get('/customers', [App\Http\Controllers\Admin\DashController::class, 'customers'])->name('admin.customers');
    
    //Drivers Routes
    Route::get('/drivers', [App\Http\Controllers\Admin\DashController::class, 'drivers'])->name('admin.drivers');
    Route::get('/drivers/create', [App\Http\Controllers\Admin\DashController::class, 'createDriver'])->name('admin.drivers.create');
    Route::post('/drivers/save', [App\Http\Controllers\Admin\DashController::class, 'saveDriver'])->name('admin.drivers.save');
    Route::put('/drivers/update/{id}', [App\Http\Controllers\Admin\DashController::class, 'updateDriver'])->name('update.driver.status');
    
    //Buses Routes
    Route::get('/buses', [App\Http\Controllers\Admin\DashController::class, 'buses'])->name('admin.buses');
    Route::get('/buses/create', [App\Http\Controllers\Admin\DashController::class, 'createBus'])->name('admin.buses.create');
    Route::post('/buses/save', [App\Http\Controllers\Admin\DashController::class, 'saveBus'])->name('admin.buses.save');
    Route::put('/bus/driver/update/{id}', [App\Http\Controllers\Admin\DashController::class, 'updateBusDriver'])->name('update.bus.driver');

    //Bus Routes Routes
    Route::get('/routes', [App\Http\Controllers\Admin\DashController::class, 'routes'])->name('admin.routes');
    Route::get('/routes/create', [App\Http\Controllers\Admin\DashController::class, 'createRoute'])->name('admin.routes.create');
    Route::post('/routes/save', [App\Http\Controllers\Admin\DashController::class, 'saveRoute'])->name('admin.routes.save');


    //Trips Routes
    Route::get('/trips', [App\Http\Controllers\Admin\DashController::class, 'trips'])->name('admin.trips');
    Route::get('/trips/completed', [App\Http\Controllers\Admin\DashController::class, 'completedTrips'])->name('admin.trips.completed');
    Route::get('/trips/scheduled', [App\Http\Controllers\Admin\DashController::class, 'scheduledTrips'])->name('admin.trips.scheduled');
    Route::get('/trips/progress', [App\Http\Controllers\Admin\DashController::class, 'progressTrips'])->name('admin.trips.progress');
    Route::get('/trips/create', [App\Http\Controllers\Admin\DashController::class, 'createDriver'])->name('admin.trips.create');


});
