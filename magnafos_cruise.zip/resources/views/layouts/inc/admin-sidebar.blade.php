<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Core</div>
                @if (Route::is('admin.dashboard'))
                    <a class="nav-link" href="{{ route('admin.dashboard') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>
                @else
                    <a class="nav-link" href="{{ route('admin.dashboard') }}">
                        <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                        Dashboard
                    </a>
                @endif


                @if (Route::is('admin.customers'))
                    <a class="nav-link" href="{{ route('admin.customers') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-user-group"></i></i></div>
                        Customers
                    </a>
                @else
                    <a class="nav-link" href="{{ route('admin.customers') }}">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-user-group"></i></i></div>
                        Customers
                    </a>
                @endif
                
                @if (Route::is('admin.drivers'))
                    <a class="nav-link" href="{{ route('admin.drivers') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-user"></i></div>
                        Drivers
                    </a>
                @elseif (Route::is('admin.drivers.create'))
                    <a class="nav-link" href="{{ route('admin.drivers') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-user"></i></div>
                        Drivers
                    </a>
                @else
                    <a class="nav-link" href="{{ route('admin.drivers') }}">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-user"></i></div>
                        Drivers
                    </a>
                @endif
                
                @if (Route::is('admin.buses'))
                    <a class="nav-link" href="{{ route('admin.buses') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-bus"></i></div>
                        Buses
                    </a>
                @elseif (Route::is('admin.buses.create'))
                    <a class="nav-link" href="{{ route('admin.buses') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-bus"></i></div>
                        Buses
                    </a>
                @else
                    <a class="nav-link" href="{{ route('admin.buses') }}">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-bus"></i></div>
                        Buses
                    </a>
                @endif
                
                @if (Route::is('admin.routes'))
                    <a class="nav-link" href="{{ route('admin.routes') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-road"></i></div>
                        Routes
                    </a>
                @elseif (Route::is('admin.routes.create'))
                    <a class="nav-link" href="{{ route('admin.routes') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-road"></i></div>
                        Routes
                    </a>
                @else
                    <a class="nav-link" href="{{ route('admin.routes') }}">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-road"></i></div>
                        Routes
                    </a>
                @endif
                
                @if (Route::is('admin.trips'))
                    <a class="nav-link" href="{{ route('admin.trips') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-suitcase"></i></div>
                        Trips
                    </a>
                @elseif (Route::is('admin.trips.completed'))
                    <a class="nav-link" href="{{ route('admin.trips') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-suitcase"></i></div>
                        Trips
                    </a>
                @elseif (Route::is('admin.trips.progress'))
                    <a class="nav-link" href="{{ route('admin.trips') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-suitcase"></i></div>
                        Trips
                    </a>
                @elseif (Route::is('admin.trips.scheduled'))
                    <a class="nav-link" href="{{ route('admin.trips') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-suitcase"></i></div>
                        Trips
                    </a>
                @else
                    <a class="nav-link" href="{{ route('admin.trips') }}">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-suitcase"></i></div>
                        Trips
                    </a>
                @endif

                
                
                @if (Route::is('admin.messages'))
                    <a class="nav-link" href="{{ route('admin.dashboard') }}" id="wht-clr">
                        <div class="sb-nav-link-icon" id="wht-clr"><i class="fa-solid fa-envelope"></i></i></div>
                        Messages
                    </a>
                @else
                    <a class="nav-link" href="{{ route('admin.dashboard') }}">
                        <div class="sb-nav-link-icon"><i class="fa-solid fa-envelope"></i></i></div>
                        Messages
                    </a>
                @endif
            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            {{ auth()->user()->first_name }} {{ auth()->user()->last_name }}
        </div>
    </nav>
</div>