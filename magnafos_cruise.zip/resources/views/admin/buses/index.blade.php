@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Buses')

@section('breadcrumbs')
    <li class="breadcrumb-item active">Buses</li>
@endsection

@section('content')
@if($errors->any())
    <div class="alert alert-success" role="alert">
        @foreach ($errors->all() as $error)
            <div>{{$error}}</div>
        @endforeach
    </div>
@endif

<div class="card mb-4">
    <div class="card-header">
        <div class="d-flex flex-row justify-content-between align-items-center">
            <i class="fas fa-table me-1 fa-2x"></i>
            <a href="{{ route('admin.buses.create') }}" class="blue-clr d-flex flex-row justify-content-center align-items-center">
                <i class="fa-solid fa-square-plus fa-2x"></i>
            </a>
        </div>
    </div>
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th>Model</th>
                    <th>Color</th>
                    <th>Plate number</th>
                    <th>Current driver</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Model</th>
                    <th>Color</th>
                    <th>Plate number</th>
                    <th>Current driver</th>
                </tr>
            </tfoot>
            <tbody>
                @foreach ($buses as $bus)
                    <tr>
                        <td>{{ $bus->bus_name }}</td>
                        <td>{{ $bus->color }}</td>
                        <td>{{ $bus->plate_number }}</td>
                        <td>
                            @if (!empty($bus->driver->first_name))
                                <div class="dropdown">
                                    <a class="btn btn-success dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                        {{ $bus->driver->first_name }} {{ $bus->driver->last_name }}
                                    </a>
                                    <ul class="dropdown-menu dropdown-menu-end z-3" aria-labelledby="navbarDropdown">
                                        @foreach ($drivers as $driver)
                                            @if($driver->id === $bus->driver->id)
                                                @continue
                                            @endif
                                            <li>
                                                <a class="dropdown-item z-3" href="{{ route('update.bus.driver', ['id' => $driver->id]) }}"
                                                    onclick="event.preventDefault();
                                                                document.getElementById('bus-driver-form').submit();">
                                                    {{ $driver->first_name }} {{ $driver->last_name }}
                                                </a>
                            
                                                <form id="bus-driver-form" action="{{ route('update.bus.driver', ['id' => $driver->id]) }}" method="POST" class="d-none">
                                                    @csrf
                                                    @method('PUT')
                                                    <input type="hidden" id="driver" name="driver" value="{{ $driver->id }}">
                                                </form>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            @else
                                <div class="dropdown">
                                    <a class="btn btn-danger dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Unassigned</a>
                                    <ul class="dropdown-menu dropdown-menu-end z-3" aria-labelledby="navbarDropdown">
                                        @foreach ($drivers as $driver)
                                            <li>
                                                <a class="dropdown-item z-3" href="{{ route('update.bus.driver', ['id' => $driver->id]) }}"
                                                    onclick="event.preventDefault();
                                                                document.getElementById('bus-driver-form').submit();">
                                                    {{ $driver->first_name }} {{ $driver->last_name }}
                                                </a>
                            
                                                <form id="bus-driver-form" action="{{ route('update.bus.driver', ['id' => $driver->id]) }}" method="POST" class="d-none">
                                                    @csrf
                                                    @method('PUT')
                                                    <input type="hidden" id="driver" name="driver" value="{{ $driver->id }}">
                                                </form>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection