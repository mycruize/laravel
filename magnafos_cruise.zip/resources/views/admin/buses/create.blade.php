@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Add Bus')

@section('breadcrumbs')
    <li class="breadcrumb-item"><a href="{{ route('admin.buses') }}">Buses</a></li>
    <li class="breadcrumb-item active">Add</li>
@endsection

@section('content')
    <div class="card shadow-lg border-0 rounded-lg mb-5 p-5">
        @if($errors->any())
            <div class="alert alert-danger" role="alert">
                @foreach ($errors->all() as $error)
                    <div>{{$error}}</div>
                @endforeach
            </div>
        @endif
        <div class="card-body">
            <form method="POST" action="{{ route('admin.buses.save') }}">
                @csrf
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <input class="form-control" name="model" type="text" placeholder="Enter your car model"  autocomplete="off" required/>
                            <label for="model">Car model</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input class="form-control" name="color" type="text" placeholder="Enter your car color"  autocomplete="off" required/>
                            <label for="color">Color</label>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <input class="form-control" name="plateNumber" type="text" placeholder="Enter your plate number"  autocomplete="off" required/>
                            <label for="plateNumber">Plate number</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <select name="driver" class="form-control">
                                <option value="">{{ __('Select driver') }}</option>
                                @foreach ($drivers as $driver)
                                    <option value="{{ $driver->id }}">{{ $driver->first_name }} {{ $driver->last_name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <input class="form-control" name="seats" type="number" placeholder="Number of seats"  autocomplete="off" required/>
                            <label for="seats">Number of seats</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input class="form-control" name="standing" type="number" placeholder="Number of standing spaces"  autocomplete="off" required/>
                            <label for="standing">Number of standing spaces</label>
                        </div>
                    </div>
                </div>
                <div class="mt-4 mb-0">
                    <button type="submit" class="btn btn-success btn-sm px-5">{{__('Save')}}</button>
                </div>
            </form>
        </div>
    </div>
@endsection