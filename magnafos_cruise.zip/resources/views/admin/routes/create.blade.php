@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Create Route')

@section('breadcrumbs')
    <li class="breadcrumb-item"><a href="{{ route('admin.routes') }}">Routes</a></li>
    <li class="breadcrumb-item active">Create Route</li>
@endsection



@section('content')
    <div class="card shadow-lg border-0 rounded-lg mb-5 p-5">
        @if($errors->any())
            <div class="alert alert-danger" role="alert">
                @foreach ($errors->all() as $error)
                    <div>{{$error}}</div>
                @endforeach
            </div>
        @endif
        <div class="card-body">
            <form method="POST" action="{{ route('admin.routes.save') }}" enctype="multipart/form-data">
                @csrf
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <input class="form-control" name="name" type="text" placeholder="Enter your first name"  autocomplete="off"/>
                            <label for="name">Route name</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <input class="form-control" type="file" id="csv" name="csv" required>
                        </div>
                    </div>
                </div>
                <div class="mt-4 mb-0">
                    <button type="submit" class="btn btn-success btn-sm px-5">{{__('Save')}}</button>
                </div>
            </form>
        </div>
    </div>
@endsection