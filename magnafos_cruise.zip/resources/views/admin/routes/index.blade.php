@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Routes')

@section('breadcrumbs')
    <li class="breadcrumb-item active">Routes</li>
@endsection


@section('content')
@if($errors->any())
    <div class="alert alert-success" role="alert">
        @foreach ($errors->all() as $error)
            <div>{{$error}}</div>
        @endforeach
    </div>
@endif


<div class="card mb-4">
    <div class="card-header">
        <div class="d-flex flex-row justify-content-between align-items-center">
            <i class="fas fa-table me-1 fa-2x"></i>
            <a href="{{ route('admin.routes.create') }}" class="blue-clr d-flex flex-row justify-content-center align-items-center">
                <i class="fa-solid fa-square-plus fa-2x"></i>
            </a>
        </div>
    </div>
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th>Route name</th>
                    <th>Junctions</th>
                    <th>Trips</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Route name</th>
                    <th>Junctions</th>
                    <th>Trips</th>
                </tr>
            </tfoot>
            <tbody>
                @foreach ($routes as $route)
                    <tr>
                        <td>{{ $route->route_name }}</td>
                        <td>{{ $route->junctions }}</td>
                        <td>{{ $route->trips }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection