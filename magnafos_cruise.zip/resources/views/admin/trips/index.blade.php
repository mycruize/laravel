@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Trips')

@section('breadcrumbs')
    <li class="breadcrumb-item active">Trips</li>
@endsection

@section('content')
<div class="row">
    <div class="col-xl-4 col-md-4">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body text-center">
                <h1>{{ $scheduled }}</h1>
                <p>Scheduled trips</p>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="{{ route('admin.trips.scheduled') }}">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-4 col-md-4">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body text-center">
                <h1>{{ $progress }}</h1>
                <p>Trips in Progress</p>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="{{ route('admin.trips.progress') }}">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-4 col-md-4">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body text-center">
                <h1>{{ $completed }}</h1>
                <p>Completed trips</p>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="{{ route('admin.trips.completed') }}">View Details</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-12 col-md-12">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body text-center">
                <h1>{{ $total }}</h1>
                <p>Total trips</p>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="#">View All</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
</div>

@endsection