@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Trips in Progress')

@section('breadcrumbs')
    <li class="breadcrumb-item"><a href="{{ route('admin.trips') }}">Trips</a></li>
    <li class="breadcrumb-item active">Trips in Progress</li>
@endsection

@section('content')
<div class="card mb-4">
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th>Route</th>
                    <th>Driver</th>
                    <th>Bus</th>
                    <th>Tickets sold</th>
                    <th>Passengers</th>
                    <th>Start time</th>
                    <th>End time</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Route</th>
                    <th>Driver</th>
                    <th>Bus</th>
                    <th>Tickets sold</th>
                    <th>Passengers</th>
                    <th>Start time</th>
                    <th>End time</th>
                </tr>
            </tfoot>
            <tbody>
                @foreach ($progress as $trip)
                    <tr>
                        <td>Michael Bruce</td>
                        <td>Javascript Developer</td>
                        <td>Singapore</td>
                        <td>29</td>
                        <td>2011/06/27</td>
                        <td>$183,000</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection