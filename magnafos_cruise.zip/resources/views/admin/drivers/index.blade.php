@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Drivers')

@section('breadcrumbs')
    <li class="breadcrumb-item active">Drivers</li>
@endsection

@section('content')
@if($errors->any())
    <div class="alert alert-success" role="alert">
        @foreach ($errors->all() as $error)
            <div>{{$error}}</div>
        @endforeach
    </div>
@endif

<div class="card mb-4">
    <div class="card-header">
        <div class="d-flex flex-row justify-content-between align-items-center">
            <i class="fas fa-table me-1 fa-2x"></i>
            <a href="{{ route('admin.drivers.create') }}" class="blue-clr d-flex flex-row justify-content-center align-items-center">
                <i class="fa-solid fa-square-plus fa-2x"></i>
            </a>
        </div>
    </div>
    <div class="card-body">
        <table id="datatablesSimple">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Status</th>
                </tr>
            </tfoot>
            <tbody>
                @foreach ($drivers as $driver)
                    <tr>
                        <td>{{ $driver->first_name }} {{ $driver->last_name }}</td>
                        <td>{{ $driver->email }}</td>
                        <td>{{ $driver->phone }}</td>
                        <td>
                            @if ($driver->status === 0)
                                <div class="dropdown">
                                    <a class="btn btn-danger dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Deactivated</a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <li>
                                            <a class="dropdown-item" href="{{ route('update.driver.status', ['id' => $driver->id]) }}"
                                                onclick="event.preventDefault();
                                                            document.getElementById('driver-status-form').submit();">
                                                Activate
                                            </a>
                        
                                            <form id="driver-status-form" action="{{ route('update.driver.status', ['id' => $driver->id]) }}" method="POST" class="d-none">
                                                @csrf
                                                @method('PUT')
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            @elseif ($driver->status === 1)
                                <div class="dropdown">
                                    <a class="btn btn-success dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Activated</a>
                                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <li>
                                            <a class="dropdown-item" href="{{ route('update.driver.status', ['id' => $driver->id]) }}"
                                                onclick="event.preventDefault();
                                                            document.getElementById('driver-status-form').submit();">
                                                Deactivate
                                            </a>
                        
                                            <form id="driver-status-form" action="{{ route('update.driver.status', ['id' => $driver->id]) }}" method="POST" class="d-none">
                                                @csrf
                                                @method('PUT')
                                            </form>
                                        </li>
                                    </ul>
                                </div>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection