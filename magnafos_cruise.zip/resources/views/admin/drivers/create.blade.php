@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Add Driver')

@section('breadcrumbs')
    <li class="breadcrumb-item"><a href="{{ route('admin.drivers') }}">Drivers</a></li>
    <li class="breadcrumb-item active">Add</li>
@endsection

@section('content')
    <div class="card shadow-lg border-0 rounded-lg mb-5 p-5">
        @if($errors->any())
            <div class="alert alert-danger" role="alert">
                @foreach ($errors->all() as $error)
                    <div>{{$error}}</div>
                @endforeach
            </div>
        @endif
        <div class="card-body">
            <form method="POST" action="{{ route('admin.drivers.save') }}">
                @csrf
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <input class="form-control" name="firstName" type="text" placeholder="Enter your first name"  autocomplete="off"/>
                            <label for="firstName">First name</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating">
                            <input class="form-control" name="lastName" type="text" placeholder="Enter your last name"  autocomplete="off"/>
                            <label for="lastName">Last name</label>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <input class="form-control" name="email" type="email" placeholder="name@example.com"  autocomplete="off"/>
                            <label for="email">Email address</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3 mb-md-0">
                            <input class="form-control" name="phone" type="phone" placeholder="Phone number"  autocomplete="off"/>
                            <label for="phone">Phone number</label>
                        </div>
                    </div>
                </div>
                <div class="mt-4 mb-0">
                    <button type="submit" class="btn btn-success btn-sm px-5">{{__('Save')}}</button>
                </div>
            </form>
        </div>
    </div>
@endsection