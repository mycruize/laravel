@extends('layouts.master')

@section('title', 'Cruise Admin Dashboard')

@section('heading', 'Buses')

@section('breadcrumbs')
    <li class="breadcrumb-item active">Buses</li>
@endsection