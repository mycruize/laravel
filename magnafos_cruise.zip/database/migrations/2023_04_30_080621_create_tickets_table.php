<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('trip_id');
            $table->unsignedBigInteger('customer_id');
            $table->unsignedBigInteger('route_id');
            $table->string('code');
            $table->string('booker_name');
            $table->string('route_name');
            $table->string('start_junction_name');
            $table->string('end_junction_name');
            $table->integer('start_junction_id');
            $table->integer('end_junction_id');
            $table->string('created_by');
            $table->string('updated_by');
            $table->timestamps();

            $table->foreign('trip_id')->references('id')->on('trips');
            $table->foreign('customer_id')->references('id')->on('customers');
            $table->foreign('route_id')->references('id')->on('routes');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tickets');
    }
};
