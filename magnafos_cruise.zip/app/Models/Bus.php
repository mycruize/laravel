<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Bus extends Model
{
    use HasFactory;

    protected $fillable = [
        'bus_name',
        'color',
        'plate_number',
        'bus_seats',
        'standing_space',
        'driver_id',
        'created_by',
        'updated_by',
    ];

    public function driver() {
        return $this->belongsTo(Driver::class);
    }
}
