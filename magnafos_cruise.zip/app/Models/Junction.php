<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Junction extends Model
{
    use HasFactory;
    
    protected $fillable = [
        'junction_name',
        'route_id',
        'order',
        'created_by',
        'updated_by',
    ];
}
