<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Bus;
use App\Models\Complaint;
use App\Models\Customer;
use App\Models\Driver;
use App\Models\Junction;
use App\Models\Route;
use App\Models\Ticket;
use App\Models\Trip;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class DashController extends Controller
{
    public function index() {
        $customers = Customer::count();
        $drivers = Driver::count();
        $buses = Bus::count();
        $complaints = Complaint::count();

        return view('admin.dashboard', [
            "customers" => $customers,
            "drivers" => $drivers,
            "buses" => $buses,
            "complaints" => $complaints,
        ]);
    }

    /**
     * 
     * Customers section
     * 
    */
    public function customers() {
        $customers = Customer::get();
        return view('admin.customers.index', [
            'customers' => $customers
        ]);
    }


    /**
     * 
     * Drivers section
     * 
    */
    public function drivers() {
        $drivers = Driver::get();
        return view('admin.drivers.index', [
            'drivers' => $drivers
        ]);
    }

    public function createDriver() {
        return view('admin.drivers.create');
    }
    
    public function saveDriver(Request $request) {
        $validator = Validator::make($request->all(),[
            'firstName' => 'required|string',
            'lastName' => 'required|string',
            'email' => 'required|email|unique:drivers',
            'phone' => 'required|string',
        ]);

        if($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        Driver::create([
            "first_name" => $request->firstName,
            "last_name" => $request->lastName,
            "email" => $request->email,
            "phone" => $request->phone,
            "created_by" => Auth::user()->first_name.' '.Auth::user()->last_name,
            "updated_by" => Auth::user()->first_name.' '.Auth::user()->last_name
        ]);

        return redirect()->route('admin.drivers')->withErrors("Created Successfully");
    }

    public function updateDriver($id) {
        $driver = Driver::find($id);

        if(!$driver->exists) {
            return redirect()->route('admin.drivers')->withErrors("Invalid Driver");
        }

        if ($driver->status == 0) {
            $driver->status = 1;
        }else {
            $driver->status = 0;
        }

        $driver->updated_by = Auth::user()->first_name.' '.Auth::user()->last_name;
        $driver->save();
        
        return redirect()->route('admin.drivers')->withErrors("Status updated Successfully");
    }



    /**
     * 
     * Buses section
     * 
    */
    public function buses() {
        $buses = Bus::select(
            'buses.id',
            'buses.bus_name',
            'buses.color',
            'buses.plate_number',
            'buses.driver_id',
            'drivers.first_name',
            'drivers.last_name',
        )->leftJoin('drivers', 'drivers.id', '=', 'buses.driver_id')->get();


        /*
        $buses = DB::table('buses')
            ->select(['buses.*', 'drivers.*', DB::raw('(SELECT COUNT() FROM buses) AS count')])
            ->leftJoin('drivers', 'drivers.id', '=', 'buses.driver_id')
            ->get();

        **/

        $drivers = Driver::whereStatus('1')->get();

        return view('admin.buses.index', [
            'buses' => $buses,
            'drivers' => $drivers
        ]);
    }

    public function createBus() {
        $drivers = Driver::get();
        return view('admin.buses.create', [
            'drivers' => $drivers
        ]);
    }
    
    public function saveBus(Request $request) {
        $validator = Validator::make($request->all(),[
            'model' => 'required|string',
            'color' => 'required|string',
            'plateNumber' => 'required|string',
            'seats' => 'required|int',
            'standing' => 'required|int',
        ]);

        if($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        if($request->driver) {
            $validator = Validator::make($request->all(),[
                'driver' => 'int',
            ]);

            if($validator->fails()) {
                return Redirect::back()->withErrors($validator);
            }
        }

        Bus::create([
            "bus_name" => $request->model,
            "color" => $request->color,
            "plate_number" => $request->plateNumber,
            "driver_id" => $request->driver,
            "bus_seats" => $request->seats,
            "standing_space" => $request->standing,
            "created_by" => Auth::user()->first_name.' '.Auth::user()->last_name,
            "updated_by" => Auth::user()->first_name.' '.Auth::user()->last_name
        ]);

        return redirect()->route('admin.buses')->withErrors("Created Successfully");
    }

    public function updateBusDriver($id, Request $request) {
        $bus = Bus::find($id);

        $validator = Validator::make($request->all(),[
            'driver' => 'required|int',
        ]);

        if($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        $driver = Driver::find($request->driver);

        if(!$driver->exists) {
            return redirect()->route('admin.buses')->withErrors("Invalid Driver");
        }

        if(!$bus->exists) {
            return redirect()->route('admin.buses')->withErrors("Invalid Bus");
        }

        $bus->driver_id = $driver->id;
        $bus->updated_by = Auth::user()->first_name.' '.Auth::user()->last_name;
        $bus->save();
        
        return redirect()->route('admin.buses')->withErrors("Driver updated updated Successfully");
    }




    /**
     * 
     * Routes section
     * 
    */
    public function routes() {
        $routes = Route::get();

        foreach ($routes as $row) {
            $rows = Junction::where('route_id', $row->id)->count();
            $row['junctions'] = $rows;
        }

        foreach ($routes as $row) {
            $rows = Trip::where('route_id', $row->id)->count();
            $row['trips'] = $rows;
        }

        return view('admin.routes.index', [
            'routes' => $routes
        ]);
    }

    public function createRoute() {
        return view('admin.routes.create');
    }

    public function saveRoute(Request $request) {
        $validator = Validator::make($request->all(),[
            'name' => 'required|string',
            'csv' => 'required|max:2048|mimes:csv',
        ]);

        if($validator->fails()) {
            return Redirect::back()->withErrors($validator);
        }

        $file = $request->file('csv');
        $path = $file->getRealPath();

        $data = array_map('str_getcsv', file($path));
        $header = $data[0];

        $csvData = array_slice($data, 1);

        $route = Route::create([
            "route_name" => $request->name,
            "created_by" => Auth::user()->first_name.' '.Auth::user()->last_name,
            "updated_by" => Auth::user()->first_name.' '.Auth::user()->last_name
        ]);
        
        foreach ($csvData as $row) {
            Junction::create([
                "junction_name" => $row[0],
                "order" => $row[1],
                "route_id" => $route->id,
                "created_by" => Auth::user()->first_name.' '.Auth::user()->last_name,
                "updated_by" => Auth::user()->first_name.' '.Auth::user()->last_name
            ]);
        }

        return redirect()->route('admin.routes')->withErrors("Created Successfully");
    }

    
    /**
     * 
     * Trips section
     * 
    */
    public function trips() {
        $scheduled = Trip::whereStatus('scheduled')->count();
        $progress = Trip::whereStatus('progress')->count();
        $completed = Trip::whereStatus('completed')->count();
        $total = Trip::count();
        
        return view('admin.trips.index', [
            'scheduled' => $scheduled,
            'progress' => $progress,
            'completed' => $completed,
            'total' => $total,
        ]);
    }

    public function completedTrips() {
        $completed = Trip::whereStatus('completed')->get();
        
        return view('admin.trips.completed', [
            'completed' => $completed,
        ]);
    }

    public function scheduledTrips() {
        $scheduled = Trip::whereStatus('scheduled')->get();
        
        return view('admin.trips.scheduled', [
            'scheduled' => $scheduled,
        ]);
    }

    public function progressTrips() {
        $progress = Trip::whereStatus('progress')->get();
        
        return view('admin.trips.progress', [
            'progress' => $progress,
        ]);
    }



}
